# ros2_daheng_camera

A ROS2 packge for Daheng USB3.0 industrial camera

## Usage

```
ros2 launch daheng_camera daheng_camera.launch.py
```

## Params

- exposure_time
- gain
- width
- height
