#include "../dahengSDK/GxIAPI.h"
#include "../dahengSDK/DxImageProc.h"
// ROS
#include <camera_info_manager/camera_info_manager.hpp>
#include <image_transport/image_transport.hpp>
#include <rclcpp/logging.hpp>
#include <rclcpp/rclcpp.hpp>
#include <rclcpp/utilities.hpp>
#include <sensor_msgs/msg/camera_info.hpp>
#include <sensor_msgs/msg/image.hpp>

namespace daheng_camera
{
class DahengCameraNode : public rclcpp::Node
{
public:
  explicit DahengCameraNode(const rclcpp::NodeOptions & options) : Node("daheng_camera", options)
  {
    RCLCPP_INFO(this->get_logger(), "Starting DahengCameraNode!");

    // 对GxIAPI进行初始化
    status = GXInitLib(); 
	if(status != GX_STATUS_SUCCESS)
	{	
		RCLCPP_INFO(this->get_logger(),"GxIAPI initialization failed!");
	}

	GX_OPEN_PARAM stOpenParam;
	uint32_t nDeviceNum = 0;
	status = GXUpdateDeviceList(&nDeviceNum, 1000);
	
	if (status == GX_STATUS_SUCCESS&&nDeviceNum> 0)
    {
        stOpenParam.accessMode = GX_ACCESS_EXCLUSIVE;
        stOpenParam.openMode = GX_OPEN_INDEX;
        const char * tmp="1";
        stOpenParam.pszContent = (char*)tmp;
        
		// 打开相机
		status=GXOpenDevice(&stOpenParam, &hDevice);

    }else if (status == GX_STATUS_SUCCESS && nDeviceNum == 0){
		
		RCLCPP_ERROR(this->get_logger(), "No camera found!");
	}

	// 设置曝光模式
	status = GXSetEnum(hDevice, GX_ENUM_EXPOSURE_MODE, GX_EXPOSURE_MODE_TIMED);
	status |= GXSetEnum(hDevice,GX_ENUM_BALANCE_WHITE_AUTO, GX_BALANCE_WHITE_AUTO_CONTINUOUS);
    // 设置自动白平衡
  status |= GXSetEnum(hDevice,GX_ENUM_AWB_LAMP_HOUSE, GX_AWB_LAMP_HOUSE_FLUORESCENCE);


    bool use_sensor_data_qos = this->declare_parameter("use_sensor_data_qos", false);
    auto qos = use_sensor_data_qos ? rmw_qos_profile_sensor_data : rmw_qos_profile_default;
    camera_pub_ = image_transport::create_camera_publisher(this, "image_raw", qos);

    declareParameters();

    //发送开采命令
    status = GXStreamOn(hDevice);

    // Load camera info
    camera_name_ = this->declare_parameter("camera_name", "narrow_stereo");
    camera_info_manager_ =
      std::make_unique<camera_info_manager::CameraInfoManager>(this, camera_name_);
    auto camera_info_url =
      this->declare_parameter("camera_info_url", "package://daheng_camera/config/camera_info.yaml");
    if (camera_info_manager_->validateURL(camera_info_url)) {
      camera_info_manager_->loadCameraInfo(camera_info_url);
      camera_info_msg_ = camera_info_manager_->getCameraInfo();
    } else {
      RCLCPP_WARN(this->get_logger(), "Invalid camera info URL: %s", camera_info_url.c_str());
    }

    params_callback_handle_ = this->add_on_set_parameters_callback(
      std::bind(&DahengCameraNode::parametersCallback, this, std::placeholders::_1));

    capture_thread_ = std::thread{[this]() -> void {
      PGX_FRAME_BUFFER pFrameBuffer = NULL;
      GX_STATUS cap_status = GX_STATUS_SUCCESS;

      RCLCPP_INFO(this->get_logger(), "Publishing image!");

      image_msg_.header.frame_id = "camera_optical_frame";
      image_msg_.encoding = "rgb8";

      VxUint32 nWidth = 0;
      VxUint32 nHeight = 0;

      DX_BAYER_CONVERT_TYPE cvtype = RAW2RGB_NEIGHBOUR; //选择插值算法
      DX_PIXEL_COLOR_FILTER nBayerType = BAYERRG; //选择图像 Bayer 格式
      bool bFlip = false;

      while (rclcpp::ok()) {
          cap_status = GXDQBuf(hDevice, &pFrameBuffer, 1000);
        if (cap_status == GX_STATUS_SUCCESS) {
            if(pFrameBuffer->nStatus == GX_FRAME_STATUS_SUCCESS){
                nWidth = pFrameBuffer->nWidth;
                nHeight = pFrameBuffer->nHeight;

                camera_info_msg_.header.stamp = image_msg_.header.stamp = this->now();
                image_msg_.height = nHeight;
                image_msg_.width = nWidth;
                image_msg_.step = nWidth * 3;
                image_msg_.data.resize(image_msg_.width * image_msg_.height * 3);

                VxInt32 DxStatus = DxRaw8toRGB24(pFrameBuffer->pImgBuf,image_msg_.data.data(),nWidth,
                                                 nHeight,cvtype,nBayerType,bFlip);

                if(DxStatus != DX_OK){
                    RCLCPP_INFO(this->get_logger(), "DxRaw8toRGB24 failed! status: [%x]", DxStatus);
                }else{
                    camera_pub_.publish(image_msg_, camera_info_msg_);
                }

            }
          // 调用GXQBuf将图像缓存重新放入缓存队列
          cap_status = GXQBuf(hDevice, pFrameBuffer);

        } else {
          RCLCPP_INFO(this->get_logger(), "Get buffer failed! status: [%x]", cap_status);
          // 重开采集
          cap_status = GXStreamOff(hDevice);
          cap_status = GXStreamOn(hDevice);
        }
      }
    }};
  }

  ~DahengCameraNode()
  {
    // 停止采集线程
    if (capture_thread_.joinable()) {
      capture_thread_.join();
    }

	// 停止采集
    status = GXStreamOff(hDevice);
	// 关闭相机
	status = GXCloseDevice(hDevice);
	// 在调用结束时释放资源
	status = GXCloseLib();
    RCLCPP_INFO(this->get_logger(), "DahengCameraNode destroyed!");
  }

private:
  void declareParameters()
  {
    rcl_interfaces::msg::ParameterDescriptor param_desc;
    
    GX_FLOAT_RANGE stFloatRange;
	GX_INT_RANGE stIntRange;

	param_desc.integer_range.resize(1);
    param_desc.integer_range[0].step = 1;


    // Exposure time
    param_desc.description = "Exposure time in microseconds";
	GXGetFloatRange(hDevice, GX_FLOAT_EXPOSURE_TIME,  &stFloatRange);
    param_desc.integer_range[0].from_value = (int)stFloatRange.dMin;
    param_desc.integer_range[0].to_value = (int)stFloatRange.dMax;
    double exposure_time = this->declare_parameter("exposure_time", 5000, param_desc);
    status = GXSetFloat(hDevice, GX_FLOAT_EXPOSURE_TIME, exposure_time);
    RCLCPP_INFO(this->get_logger(), "Exposure time: %f", exposure_time);

     // Gain
     param_desc.description = "Gain";
	 GXGetFloatRange(hDevice, GX_FLOAT_GAIN, &stFloatRange);
     param_desc.integer_range[0].from_value =0.0;// (int)stFloatRange.dMin;
     param_desc.integer_range[0].to_value =100.0;// (int)stFloatRange.dMax;
     double gain = this->declare_parameter("gain", 32.0, param_desc);
     status |= GXSetEnum(hDevice, GX_ENUM_GAIN_AUTO, GX_GAIN_AUTO_CONTINUOUS);
     RCLCPP_INFO(this->get_logger(), "Gain: %f", gain);
	
	// Width and Height
	param_desc.description = "Width";
	GXGetIntRange(hDevice, GX_INT_WIDTH, &stIntRange);
	param_desc.integer_range[0].from_value = stIntRange.nMin;
	param_desc.integer_range[0].to_value = stIntRange.nMax;
	int width = this->declare_parameter("Width", 1280,param_desc);
	status |= GXSetInt(hDevice, GX_INT_WIDTH, width);
	RCLCPP_INFO(this->get_logger(), "Width: %d", width);
	
	param_desc.description = "Height";
    GXGetIntRange(hDevice, GX_INT_HEIGHT, &stIntRange);
    param_desc.integer_range[0].from_value = stIntRange.nMin;
    param_desc.integer_range[0].to_value = stIntRange.nMax;
	int height = this->declare_parameter("Height", 720,param_desc);
	status |= GXSetInt(hDevice, GX_INT_HEIGHT, height);
	RCLCPP_INFO(this->get_logger(), "Height: %d", height);

    // Frame rate
    param_desc.description = "Frame rate";
    param_desc.integer_range[0].from_value = 1;
    param_desc.integer_range[0].to_value = 300;
    double frame_rate = this->declare_parameter("frame_rate", 250, param_desc);
    status |= GXSetEnum(hDevice, GX_ENUM_ACQUISITION_FRAME_RATE_MODE, GX_ACQUISITION_FRAME_RATE_MODE_ON);
    status |= GXSetFloat(hDevice, GX_FLOAT_ACQUISITION_FRAME_RATE, frame_rate);
    RCLCPP_INFO(this->get_logger(), "Frame rate: %f", frame_rate);


  }

  rcl_interfaces::msg::SetParametersResult parametersCallback(
    const std::vector<rclcpp::Parameter> & parameters)
  {
    rcl_interfaces::msg::SetParametersResult result;
    result.successful = true;
    for (const auto & param : parameters) {
      if (param.get_name() == "exposure_time") {
		int sts = GXSetFloat(hDevice, GX_FLOAT_EXPOSURE_TIME, param.as_int());
        if (GX_STATUS_SUCCESS != sts) {
          result.successful = false;
          result.reason = "Failed to set exposure time, status = " + std::to_string(status);
        }
        RCLCPP_INFO(this->get_logger(), "Exposure time set to %ld", param.as_int());
      } else if (param.get_name() == "gain") {
        int sts = GXSetFloat(hDevice, GX_FLOAT_GAIN, param.as_double());
         if (GX_STATUS_SUCCESS != sts) {
           result.successful = false;
           result.reason = "Failed to set gain, status = " + std::to_string(status);
         }
        RCLCPP_INFO(this->get_logger(), "Gain set to %f", param.as_double());
      } else if (param.get_name() == "width") {
        int sts = GXSetInt(hDevice, GX_INT_WIDTH, param.as_int());
        if (GX_STATUS_SUCCESS != sts) {
          result.successful = false;
          result.reason = "Failed to set gain, status = " + std::to_string(status);
        }
        RCLCPP_INFO(this->get_logger(), "Width set to %ld", param.as_int());
      } else if (param.get_name() == "height") {
        int sts = GXSetInt(hDevice, GX_INT_HEIGHT, param.as_int());
        if (GX_STATUS_SUCCESS != sts) {
          result.successful = false;
          result.reason = "Failed to set gain, status = " + std::to_string(status);
        }
        RCLCPP_INFO(this->get_logger(), "Height set to %ld", param.as_int());
      } else {
        result.successful = false;
        result.reason = "Unknown parameter: " + param.get_name();
      }
    }
    return result;
  }

  sensor_msgs::msg::Image image_msg_;

  image_transport::CameraPublisher camera_pub_;

  GX_STATUS status = GX_STATUS_SUCCESS;
  
  GX_DEV_HANDLE hDevice;

  std::string camera_name_;
  std::unique_ptr<camera_info_manager::CameraInfoManager> camera_info_manager_;
  sensor_msgs::msg::CameraInfo camera_info_msg_;

  std::thread capture_thread_;

  OnSetParametersCallbackHandle::SharedPtr params_callback_handle_;
};
}  // namespace daheng_camera

#include "rclcpp_components/register_node_macro.hpp"

RCLCPP_COMPONENTS_REGISTER_NODE(daheng_camera::DahengCameraNode)
