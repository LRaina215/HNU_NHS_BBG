# ros2_hik_camera

A ROS2 packge for Hikvision USB3.0 industrial camera

##开发流程

![img.png](img.png)

## Usage

```
ros2 launch hik_camera hik_camera.launch.py
```

## Params

- exposure_time
- gain
