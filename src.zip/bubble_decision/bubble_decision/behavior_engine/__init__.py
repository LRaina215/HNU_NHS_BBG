'''
Copyright (c) 2022 Birdiebot R&D Department
Shanghai University Of Engineering Science. All Rights Reserved

License: GNU General Public License v3.0.
See LICENSE file in root directory.
Author: Ligcox
Date: 2022-05-27 00:48:01
FilePath: /bubble_bringup/home/nvidia/Desktop/bubble/src/bubble_contrib/bubble_decision/bubble_decision/behavior_engine/__init__.py
LastEditors: Ligcox
LastEditTime: 2022-05-27 00:48:23
E-mail: robomaster@birdiebot.top
'''
